<style lang="scss">
.p22 {
  background-image: url("/img/pages/21.jpg");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;

  //paragraf 1
  .content1 {
    position: absolute;
    top: 190px;
    left: 0px;
    width: 100px;
    text-align: left;

    @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
      top: 25px;
      left: 125px;
      width: 100px;
      //line-height: 10px;
    }

    @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
      top: 172px;
      left: 50px;
      width: 211px;
    }

    @media (min-width: $breakpoint-sm) and (max-width: 480px) {
      top: 25px;
      left: 90px;
      width: 197px;
    }

    .text {
      span {
        color: #ffffff;
        font-weight: 900;

        @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
          font-size: 19px;
        }

        @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
          font-size: 0.8rem;
        }

        @media (min-width: $breakpoint-sm) and (max-width: 480px) {
          font-size: 0.8rem;
        }
      }
    }
  }
  //paragraf 2
  .content2 {
    position: absolute;
    top: 263px;
    left: 28px;
    text-align: center;
    line-height: 13px;
    font-size: 8px;

    @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
      top: 185px;
      left: 40px;
      width: 80px;
    }

    @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
      top: 229px;
      left: 27px;
      width: 207px;
    }

    @media (min-width: $breakpoint-sm) and (max-width: 480px) {
      top: 172px;
      left: 24px;
      width: 80px;
    }

    .text {
      color: #ffffff;
      font-size: 0.7rem;
      font-size: 900;

      @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
        font-size: 7px;
        line-height: 9px;
      }

      @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
        font-size: 0.65rem;
        line-height: 11px;
      }

      @media (min-width: $breakpoint-sm) and (max-width: 480px) {
        font-size: 7px;
        line-height: 9px;
      }
    }
  }
  //paragraf 3
  .content3 {
    position: absolute;
    top: 263px;
    left: 28px;
    text-align: center;
    line-height: 13px;
    font-size: 8px;

    @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
      top: 185px;
      left: 135px;
      width: 80px;
    }

    @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
      top: 229px;
      left: 27px;
      width: 207px;
    }

    @media (min-width: $breakpoint-sm) and (max-width: 480px) {
      top: 172px;
      left: 120px;
      width: 80px;
    }

    .text {
      color: #ffffff;
      font-size: 0.7rem;

      @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
        font-size: 7px;
        line-height: 9px;
      }

      @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
        font-size: 0.65rem;
        line-height: 11px;
      }

      @media (min-width: $breakpoint-sm) and (max-width: 480px) {
        font-size: 7px;
        line-height: 8px;
      }
    }
  }
  //paragraf 4
  .content4 {
    position: absolute;
    top: 263px;
    left: 28px;
    text-align: center;
    line-height: 13px;
    font-size: 8px;

    @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
      top: 185px;
      left: 225px;
      width: 80px;
    }

    @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
      top: 229px;
      left: 27px;
      width: 207px;
    }

    @media (min-width: $breakpoint-sm) and (max-width: 480px) {
      top: 172px;
      left: 207px;
      width: 80px;
    }

    .text {
      color: #ffffff;
      font-size: 0.7rem;

      @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
        font-size: 7px;
        line-height: 9px;
      }

      @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
        font-size: 0.65rem;
        line-height: 11px;
      }

      @media (min-width: $breakpoint-sm) and (max-width: 480px) {
        font-size: 7px;
        line-height: 8px;
      }
    }
  }
  //paragraf 5
  .content5 {
    position: absolute;
    top: 263px;
    left: 1000px;
    text-align: center;
    line-height: 13px;
    font-size: 7px;

    @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
      top: 310px;
      left: 103px;
      width: 80px;
    }

    @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
      top: 229px;
      left: 27px;
      width: 207px;
    }

    @media (min-width: $breakpoint-sm) and (max-width: 480px) {
      top: 290px;
      left: 65px;
      width: 110px;
    }

    .text {
      color: #ffffff;
      font-size: 15px;

      @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
        font-size: 7.7px;
        line-height: 9px;
      }

      @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
        font-size: 0.65rem;
        line-height: 11px;
      }

      @media (min-width: $breakpoint-sm) and (max-width: 480px) {
        font-size: 7px;
        line-height: 9px;
      }
    }
  }
  //paragraf 6
  .content6 {
    position: absolute;
    top: 263px;
    left: 1000px;
    text-align: center;
    line-height: 13px;
    font-size: 7px;

    @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
      top: 310px;
      left: 190px;
      width: 80px;
    }

    @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
      top: 229px;
      left: 27px;
      width: 207px;
    }

    @media (min-width: $breakpoint-sm) and (max-width: 480px) {
      top: 290px;
      left: 145px;
      width: 120px;
    }

    .text {
      color: #ffffff;
      font-size: 15px;

      @media (min-width: $breakpoint-lg) and (max-width: ($breakpoint-xl - 1px)) {
        font-size: 7.7px;
        line-height: 9px;
      }

      @media (min-width: 481px) and (max-width: ($breakpoint-lg - 1px)) {
        font-size: 0.65rem;
        line-height: 11px;
      }

      @media (min-width: $breakpoint-sm) and (max-width: 480px) {
        font-size: 7px;
        line-height: 9px;
      }
    }
  }
  
}
</style>

<template>
  <div>
    <div style="display: none">
      <div id="p21p1">{{ $t("p21.paragraph1") }}</div>
      <div id="p21p2">{{ $t("p21.paragraph2") }}</div>
      <div id="p21p3">{{ $t("p21.paragraph3") }}</div>
      <div id="p21p4">{{ $t("p21.paragraph4") }}</div>
      <div id="p21p5">{{ $t("p21.paragraph5") }}</div>
      <div id="p21p6">{{ $t("p21.paragraph6") }}</div>
    </div>
    <div class="content1">
      <div id="p21p1_" class="text"></div>
    </div>
    <div class="content2">
      <div id="p21p2_" class="text"></div>
    </div>
    <div class="content3">
      <div id="p21p3_" class="text"></div>
    </div>
    <div class="content4">
      <div id="p21p4_" class="text"></div>
    </div>
    <div class="content5">
      <div id="p21p5_" class="text"></div>
    </div>
    <div class="content6">
      <div id="p21p6_" class="text"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Page21",
  mounted() {
    let ref = this;
    ref.processText("p21p1");
    ref.processText("p21p2");
    ref.processText("p21p3");
    ref.processText("p21p4");
    ref.processText("p21p5");
    ref.processText("p21p6");
    window
      .jQuery("body")
      .on("DOMSubtreeModified", " #p21p1, #p21p2, #p21p3, #p21p4, #p21p5, #p21p6", function () {
        ref.processText(window.jQuery(this).attr("id"));
      });
  },
  methods: {
    processText(id) {
      let text = document.getElementById(id).textContent;
      let r = text.split("");
      document.getElementById(id + "_").innerHTML = "";
      window.jQuery.each(r, function (i, w) {
        var node = document.createElement("span");
        var textnode = document.createTextNode(
          w + (id.slice(-1) == "t" || id.slice(-1) == "s" ? "" : "")
        );
        node.appendChild(textnode);
        document.getElementById(id + "_").appendChild(node);
      });
    },
  },
};
</script>