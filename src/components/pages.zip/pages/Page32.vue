<style lang="scss" scoped>
.p33 {
  background-image: url("/img/pages/32.jpg");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}
</style>

<template>
  <div>
    <div class="content"></div>
  </div>
</template>

<script>
export default {
  name: "Page32",
};
</script>