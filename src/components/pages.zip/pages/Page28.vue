<style lang="scss" scoped>
.p29 {
  background-image: url("/img/pages/28.jpg");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;

  .title {
    position: absolute;
    top: 35px;
    left: 20px;

    font-size: 1rem;
    line-height: 17px;

    width: 150px;

    span {
      font-weight: 700;
    }
  }

  .content {
    position: absolute;
    top: 70px;
    right: 0;
    width: 211px;

    padding-left: 20px;
    padding-right: 20px;

    text-align: justify;

    font-size: 0.5rem;
    line-height: 9px;

    .text1,
    .text2 {
      margin-bottom: 60px;
    }
  }

  .image1 {
    position: absolute;
    top: 34px;

    width: 100px;
    height: 118.5px;

    object-fit: cover;
  }

  .image2 {
    position: absolute;
    top: 156px;

    width: 100px;
    height: 118.5px;
  }

  .image3 {
    position: absolute;
    top: 278px;

    width: 100px;
    height: 118.5px;
  }
}
</style>

<template>
  <div>
    <div style="display: none">
      <div id="p28p1">{{ $t("p28.paragraph1") }}</div>
      <div id="p28p2">{{ $t("p28.paragraph2") }}</div>
      <div id="p28p3">{{ $t("p28.paragraph3") }}</div>
    </div>

    <div class="content">
      <div id="p28p1_" class="text1"></div>
      <div id="p28p2_" class="text2"></div>
      <div id="p28p3_" class="text3"></div>
    </div>

    <img class="image1" src="/img/h.jpeg" alt="" />
    <img class="image2" src="/img/f.jpg" alt="" />
    <img class="image3" src="/img/z.jpg" alt="" />
  </div>
</template>

<script>
export default {
  name: "Page28",
  mounted() {
    let ref = this;
    ref.processText("p28p1");
    ref.processText("p28p2");
    ref.processText("p28p3");
    window
      .jQuery("body")
      .on("DOMSubtreeModified", "#p28p1,#p28p2,#p28p3", function () {
        ref.processText(window.jQuery(this).attr("id"));
      });
  },
  methods: {
    processText(id) {
      let text = document.getElementById(id).textContent;
      let r = text.split(".");
      document.getElementById(id + "_").innerHTML = "";
      window.jQuery.each(r, function (i, w) {
        var node = document.createElement("span");
        var textnode = document.createTextNode(
          w + (id.slice(-1) == "t" || id.slice(-1) == "s" ? "" : ".")
        );
        node.appendChild(textnode);
        document.getElementById(id + "_").appendChild(node);
      });
    },
    showImage(url) {
      this.$parent.showImage(url);
    },
  },
};
</script>